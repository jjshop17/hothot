# bot-discord-auto-random-chat
<h3 align="center">Auto Sends Random Message Every Time</h3>

# TUTORIAL FOR WINDOWS
  1. Download and install python
  2. input your token discord in Config.json file
  3. open install.bat
  4. open start.bat
  5. input delay chat and delay delete message in seconds
  6. write in discord chat `!ikuzo <number of messages>`
  
# TUTORIAL FOR ANDROID
  1. Dowload and install Termux
  2. input your token discord in Config.json file
  3. input this command in termux:<br>
     <q>pkg install python3</q><br>
     <q>pip install -r requirements.txt</q><br>
     <q>python3 main.py</q><br>
  4. input delay chat and delay delete message in seconds
  5. write in discord chat `!ikuzo <number of messages>`
    
# NOTE
  You can edit messages in line 46 main.py
  
<h2 align="center">!!! DWYOR !!!</h2>
